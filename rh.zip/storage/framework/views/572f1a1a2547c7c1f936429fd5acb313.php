
<div class="modal fade" id="modalAsignarHoras<?php echo e($trabajador->id_trabajador); ?>" tabindex="-1" aria-labelledby="modalAsignarHorasLabel<?php echo e($trabajador->id_trabajador); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <form method="POST" action="<?php echo e(route('trabajadores.horas-extra.asignar', $trabajador->id_trabajador)); ?>">
            <?php echo csrf_field(); ?>

                
                
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="modalAsignarHorasLabel<?php echo e($trabajador->id_trabajador); ?>">
                        <i class="bi bi-plus-circle"></i> Asignar Horas Extra
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>

                
                <div class="modal-body">
                    
                    <div class="alert alert-info mb-4">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="mb-1">
                                    <i class="bi bi-person-fill"></i> <?php echo e($trabajador->nombre_completo); ?>

                                </h6>
                                <small class="text-muted">
                                    <?php echo e($trabajador->fichaTecnica->categoria->area->nombre_area ?? 'N/A'); ?> - 
                                    <?php echo e($trabajador->fichaTecnica->categoria->nombre_categoria ?? 'N/A'); ?>

                                </small>
                            </div>
                            <div class="col-md-4 text-end">
                                <?php
                                    $saldoActualAsignar = \App\Models\HorasExtra::calcularSaldo($trabajador->id_trabajador);
                                ?>
                                <div class="badge bg-primary fs-6">
                                    <i class="bi bi-clock"></i> 
                                    <?php echo e($saldoActualAsignar); ?> <?php echo e($saldoActualAsignar == 1 ? 'hora' : 'horas'); ?>

                                </div>
                                <div class="small text-muted mt-1">Saldo actual</div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row g-3">
                        
                        <div class="col-md-6">
                            <label for="horas_asignar<?php echo e($trabajador->id_trabajador); ?>" class="form-label">
                                <i class="bi bi-clock-fill text-success"></i> Horas Extra Trabajadas <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['horas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="horas_asignar<?php echo e($trabajador->id_trabajador); ?>" 
                                       name="horas" 
                                       value="<?php echo e(old('horas')); ?>"
                                       min="1" 
                                       max="24" 
                                       step="1" 
                                       placeholder="0"
                                       required>
                                <span class="input-group-text"><?php echo e(old('horas') == 1 ? 'hora' : 'horas'); ?></span>
                                <?php $__errorArgs = ['horas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-text">
                                <i class="bi bi-info-circle"></i> 
                                Mínimo: 1 hora | Máximo: 24 horas completas
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <label for="fecha_asignar<?php echo e($trabajador->id_trabajador); ?>" class="form-label">
                                <i class="bi bi-calendar3"></i> Fecha del Trabajo <span class="text-danger">*</span>
                            </label>
                            <input type="date" 
                                   class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="fecha_asignar<?php echo e($trabajador->id_trabajador); ?>" 
                                   name="fecha" 
                                   value="<?php echo e(old('fecha', now()->format('Y-m-d'))); ?>"
                                   max="<?php echo e(now()->format('Y-m-d')); ?>"
                                   min="<?php echo e(now()->subDays(30)->format('Y-m-d')); ?>"
                                   required>
                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-text">
                                <i class="bi bi-exclamation-triangle"></i> 
                                Máximo 30 días atrás
                            </div>
                        </div>

                        
                        <div class="col-12">
                            <label for="descripcion_asignar<?php echo e($trabajador->id_trabajador); ?>" class="form-label">
                                <i class="bi bi-chat-left-text"></i> Descripción o Motivo
                            </label>
                            <textarea class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      id="descripcion_asignar<?php echo e($trabajador->id_trabajador); ?>" 
                                      name="descripcion" 
                                      rows="3" 
                                      placeholder="Ej: Trabajo extra por evento especial, horario extendido, etc..."
                                      maxlength="200"><?php echo e(old('descripcion')); ?></textarea>
                            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-text">
                                <span id="contadorAsignar<?php echo e($trabajador->id_trabajador); ?>">0</span>/200 caracteres
                            </div>
                        </div>

                        
                        <div class="col-12">
                            <div class="card border-success">
                                <div class="card-body bg-light">
                                    <h6 class="card-title text-success">
                                        <i class="bi bi-calculator"></i> Resumen de Asignación
                                    </h6>
                                    <div class="row text-center">
                                        <div class="col-4">
                                            <div class="h5 text-primary mb-1"><?php echo e($saldoActualAsignar); ?></div>
                                            <small class="text-muted">Saldo Actual</small>
                                        </div>
                                        <div class="col-1 align-self-center">
                                            <i class="bi bi-plus text-success"></i>
                                        </div>
                                        <div class="col-3">
                                            <div class="h5 text-success mb-1">
                                                <span id="horasAAsignar<?php echo e($trabajador->id_trabajador); ?>">0</span>
                                            </div>
                                            <small class="text-muted">A Asignar</small>
                                        </div>
                                        <div class="col-1 align-self-center">
                                            <i class="bi bi-equals text-primary"></i>
                                        </div>
                                        <div class="col-3">
                                            <div class="h5 text-primary mb-1">
                                                <span id="saldoFinalAsignar<?php echo e($trabajador->id_trabajador); ?>"><?php echo e($saldoActualAsignar); ?></span>
                                            </div>
                                            <small class="text-muted">Horas Acumuladas</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="mt-4">
                        <div class="alert alert-light border">
                            <h6 class="mb-2">
                                <i class="bi bi-lightbulb text-warning"></i> Información Importante
                            </h6>
                            <ul class="mb-0 small">
                                <li>Las horas extra se acumularán al saldo del trabajador</li>
                                <li>Solo se registran <strong>horas completas</strong> (sin fracciones)</li>
                                <li>Estas horas podrán ser compensadas posteriormente</li>
                                <li>El registro quedará en el historial laboral</li>
                                <li>Solo se pueden registrar horas de los últimos 30 días</li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Asignar Horas Extra
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const textarea = document.getElementById('descripcion_asignar<?php echo e($trabajador->id_trabajador); ?>');
    const contador = document.getElementById('contadorAsignar<?php echo e($trabajador->id_trabajador); ?>');
    const inputHoras = document.getElementById('horas_asignar<?php echo e($trabajador->id_trabajador); ?>');
    const spanHorasAAsignar = document.getElementById('horasAAsignar<?php echo e($trabajador->id_trabajador); ?>');
    const spanSaldoFinal = document.getElementById('saldoFinalAsignar<?php echo e($trabajador->id_trabajador); ?>');
    const saldoActual = <?php echo e($saldoActualAsignar); ?>;
    
    // Contador de caracteres
    if (textarea && contador) {
        textarea.addEventListener('input', function() {
            contador.textContent = this.value.length;
        });
        
        // Inicializar contador
        contador.textContent = textarea.value.length;
    }
    
    // Calculadora de saldo resultante
    if (inputHoras && spanHorasAAsignar && spanSaldoFinal) {
        inputHoras.addEventListener('input', function() {
            const horasAAsignar = parseInt(this.value) || 0;
            const saldoFinal = saldoActual + horasAAsignar;
            
            spanHorasAAsignar.textContent = horasAAsignar;
            spanSaldoFinal.textContent = saldoFinal;
        });
    }
});
</script><?php /**PATH C:\xampp\htdocs\Fichas-Tecnicas\TasbascoInn-Workers\resources\views/trabajadores/modales/asignar_horas_extras.blade.php ENDPATH**/ ?>