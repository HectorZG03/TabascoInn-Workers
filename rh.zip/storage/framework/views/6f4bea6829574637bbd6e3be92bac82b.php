

<div class="row">
    
    <div class="col-12 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0">
                    <i class="bi bi-clock-fill text-warning"></i> Resumen de Horas Extra
                </h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <!-- Horas Acumuladas -->
                    <div class="col-md-3">
                        <div class="border-end">
                            <div class="h3 text-success mb-1"><?php echo e($stats_horas['total_acumuladas']); ?></div>
                            <div class="text-muted"><?php echo e($stats_horas['total_acumuladas'] == 1 ? 'Hora Acumulada' : 'Horas Acumuladas'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Horas Compensadas -->
                    <div class="col-md-3">
                        <div class="border-end">
                            <div class="h3 text-warning mb-1"><?php echo e($stats_horas['total_devueltas']); ?></div>
                            <div class="text-muted"><?php echo e($stats_horas['total_devueltas'] == 1 ? 'Hora Compensada' : 'Horas Compensadas'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Saldo Actual -->
                    <div class="col-md-3">
                        <div class="border-end">
                            <div class="h3 text-primary mb-1"><?php echo e($trabajador->saldo_horas_extra); ?></div>
                            <div class="text-muted"><?php echo e($trabajador->saldo_horas_extra == 1 ? 'Hora Disponible' : 'Horas Disponibles'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Total de Registros -->
                    <div class="col-md-3">
                        <div class="h3 text-info mb-1"><?php echo e($stats_horas['total_registros']); ?></div>
                        <div class="text-muted"><?php echo e($stats_horas['total_registros'] == 1 ? 'Registro Total' : 'Registros Totales'); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-12 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-light">
                <h6 class="mb-0">
                    <i class="bi bi-lightning-fill text-primary"></i> Acciones Rápidas
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <?php if(!$trabajador->estaSuspendido() && !$trabajador->estaInactivo()): ?>
                            <button type="button" 
                                    class="btn btn-success w-100" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#modalAsignarHoras<?php echo e($trabajador->id_trabajador); ?>">
                                <i class="bi bi-plus-circle"></i> Asignar Horas Extra
                            </button>
                        <?php else: ?>
                            <button type="button" class="btn btn-success w-100 disabled" disabled>
                                <i class="bi bi-plus-circle"></i> Asignar Horas Extra
                                <br><small>(Trabajador <?php echo e($trabajador->estatus_texto); ?>)</small>
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(!$trabajador->estaSuspendido() && !$trabajador->estaInactivo() && $trabajador->saldo_horas_extra > 0): ?>
                            <button type="button" 
                                    class="btn btn-warning w-100" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#modalRestarHoras<?php echo e($trabajador->id_trabajador); ?>">
                                <i class="bi bi-dash-circle"></i> Compensar Horas Extra
                            </button>
                        <?php else: ?>
                            <button type="button" class="btn btn-warning w-100 disabled" disabled>
                                <i class="bi bi-dash-circle"></i> Compensar Horas Extra
                                <br><small>
                                    <?php if($trabajador->estaSuspendido() || $trabajador->estaInactivo()): ?>
                                        (Trabajador <?php echo e($trabajador->estatus_texto); ?>)
                                    <?php else: ?>
                                        (Sin horas disponibles)
                                    <?php endif; ?>
                                </small>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header bg-light">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h6 class="mb-0">
                            <i class="bi bi-list-ul"></i> Historial de Horas Extra
                        </h6>
                    </div>
                    <div class="col-md-6">
                        
                        <div class="d-flex gap-2 justify-content-end">
                            <select class="form-select form-select-sm" id="filtroTipo" style="width: auto;">
                                <option value="">Todos los tipos</option>
                                <option value="acumuladas">Solo Acumuladas</option>
                                <option value="devueltas">Solo Compensadas</option>
                            </select>
                            <select class="form-select form-select-sm" id="filtroPeriodo" style="width: auto;">
                                <option value="">Todo el historial</option>
                                <option value="7">Últimos 7 días</option>
                                <option value="30">Últimos 30 días</option>
                                <option value="90">Últimos 3 meses</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if($historial_horas->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0" id="tablaHistorial">
                            <thead class="table-light">
                                <tr>
                                    <th>Fecha</th>
                                    <th>Tipo</th>
                                    <th>Horas</th>
                                    <th>Descripción</th>
                                    <th>Autorizado por</th>
                                    <th>Registro</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $historial_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-tipo="<?php echo e($registro->tipo); ?>" data-fecha="<?php echo e($registro->fecha->format('Y-m-d')); ?>">
                                        <td>
                                            <div class="fw-medium"><?php echo e($registro->fecha_formateada); ?></div>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($registro->color_tipo); ?> fs-6">
                                                <i class="<?php echo e($registro->icono_tipo); ?>"></i>
                                                <?php echo e($registro->tipo_texto); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-<?php echo e($registro->color_tipo); ?>">
                                                <?php echo e($registro->horas_formateadas); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-muted">
                                                <?php echo e($registro->descripcion ?? 'Sin descripción'); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo e($registro->autorizado_por); ?>

                                            </small>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo e($registro->created_at->format('d/m/Y H:i')); ?>

                                            </small>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="card-footer bg-light">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <small class="text-muted">
                                    <i class="bi bi-info-circle"></i>
                                    Mostrando <?php echo e($historial_horas->count()); ?> registros.
                                    <?php if($stats_horas['ultimo_registro']): ?>
                                        Último movimiento: <?php echo e($stats_horas['ultimo_registro']->format('d/m/Y')); ?>

                                    <?php endif; ?>
                                </small>
                            </div>
                            <div class="col-md-4 text-end">
                                <small class="text-muted">
                                    Balance neto: 
                                    <span class="fw-bold text-<?php echo e($trabajador->saldo_horas_extra > 0 ? 'success' : 'secondary'); ?>">
                                        <?php echo e($trabajador->saldo_horas_extra); ?> <?php echo e($trabajador->saldo_horas_extra == 1 ? 'hora' : 'horas'); ?>

                                    </span>
                                </small>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    
                    <div class="text-center py-5">
                        <div class="mb-3">
                            <i class="bi bi-clock text-muted" style="font-size: 4rem;"></i>
                        </div>
                        <h5 class="text-muted">No hay registros de horas extra</h5>
                        <p class="text-muted mb-4">
                            Este trabajador aún no tiene horas extra registradas.
                        </p>
                        <?php if(!$trabajador->estaSuspendido() && !$trabajador->estaInactivo()): ?>
                            <button type="button" 
                                    class="btn btn-primary" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#modalAsignarHoras<?php echo e($trabajador->id_trabajador); ?>">
                                <i class="bi bi-plus-circle"></i> Registrar Primera Hora Extra
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const filtroTipo = document.getElementById('filtroTipo');
    const filtroPeriodo = document.getElementById('filtroPeriodo');
    const tablaHistorial = document.getElementById('tablaHistorial');
    
    if (!tablaHistorial) return; // No hay tabla si no hay registros
    
    const filas = tablaHistorial.querySelectorAll('tbody tr');
    
    function aplicarFiltros() {
        const tipoSeleccionado = filtroTipo.value;
        const periodoSeleccionado = filtroPeriodo.value;
        const fechaLimite = periodoSeleccionado ? 
            new Date(Date.now() - (parseInt(periodoSeleccionado) * 24 * 60 * 60 * 1000)) : null;
        
        filas.forEach(fila => {
            let mostrar = true;
            
            // Filtro por tipo
            if (tipoSeleccionado && fila.dataset.tipo !== tipoSeleccionado) {
                mostrar = false;
            }
            
            // Filtro por período
            if (fechaLimite && mostrar) {
                const fechaRegistro = new Date(fila.dataset.fecha);
                if (fechaRegistro < fechaLimite) {
                    mostrar = false;
                }
            }
            
            fila.style.display = mostrar ? '' : 'none';
        });
        
        // Actualizar contador
        const filasVisibles = Array.from(filas).filter(f => f.style.display !== 'none').length;
        const infoElement = document.querySelector('.card-footer small');
        if (infoElement) {
            infoElement.innerHTML = `<i class="bi bi-info-circle"></i> Mostrando ${filasVisibles} de ${filas.length} registros.`;
        }
    }
    
    if (filtroTipo) {
        filtroTipo.addEventListener('change', aplicarFiltros);
    }
    
    if (filtroPeriodo) {
        filtroPeriodo.addEventListener('change', aplicarFiltros);
    }
    
    console.log('✅ Sección horas extra inicializada correctamente');
});
</script><?php /**PATH C:\xampp\htdocs\Fichas-Tecnicas\TasbascoInn-Workers\resources\views/trabajadores/secciones_perfil/horas_extra.blade.php ENDPATH**/ ?>