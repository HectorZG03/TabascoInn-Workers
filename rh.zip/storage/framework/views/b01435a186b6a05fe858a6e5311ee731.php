

<div class="card shadow">
    <div class="card-header bg-warning text-dark">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="bi bi-files"></i> Documentos del Trabajador
            </h5>
            <div>
                <span class="badge bg-<?php echo e($trabajador->documentos?->color_progreso ?? 'secondary'); ?> fs-6">
                    <?php echo e($stats['porcentaje_documentos']); ?>% Completado
                </span>
            </div>
        </div>
    </div>
    <div class="card-body">
        <!-- Progreso de Documentos -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="progress mb-2" style="height: 10px;">
                    <div class="progress-bar bg-<?php echo e($trabajador->documentos?->color_progreso ?? 'secondary'); ?>" 
                         style="width: <?php echo e($stats['porcentaje_documentos']); ?>%"></div>
                </div>
                <div class="d-flex justify-content-between small text-muted">
                    <span><?php echo e(count(\App\Models\DocumentoTrabajador::TODOS_DOCUMENTOS) - $stats['documentos_faltantes']); ?> de <?php echo e(count(\App\Models\DocumentoTrabajador::TODOS_DOCUMENTOS)); ?> documentos</span>
                    <span><?php echo e($stats['estado_documentos']); ?></span>
                </div>
            </div>
        </div>

        <!-- Lista de Documentos -->
        <div class="row">
            <?php $__currentLoopData = \App\Models\DocumentoTrabajador::TODOS_DOCUMENTOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $tieneDocumento = $trabajador->documentos && !empty($trabajador->documentos->$campo);
                    $esBasico = array_key_exists($campo, \App\Models\DocumentoTrabajador::DOCUMENTOS_BASICOS);
                ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card border-<?php echo e($tieneDocumento ? 'success' : ($esBasico ? 'warning' : 'light')); ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0">
                                    <?php echo e($nombre); ?>

                                    <?php if($esBasico): ?>
                                        <span class="badge bg-warning text-dark ms-1">Básico</span>
                                    <?php endif; ?>
                                </h6>
                                <?php if($tieneDocumento): ?>
                                    <i class="bi bi-check-circle text-success"></i>
                                <?php else: ?>
                                    <i class="bi bi-x-circle text-muted"></i>
                                <?php endif; ?>
                            </div>
                            
                            <?php if($tieneDocumento): ?>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(Storage::disk('public')->url($trabajador->documentos->$campo)); ?>" 
                                       target="_blank" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i> Ver
                                    </a>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-secondary" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#uploadModal"
                                            data-tipo="<?php echo e($campo); ?>"
                                            data-nombre="<?php echo e($nombre); ?>">
                                        <i class="bi bi-arrow-repeat"></i> Cambiar
                                    </button>
                                    <form action="<?php echo e(route('trabajadores.perfil.delete-document', $trabajador)); ?>" 
                                          method="POST" 
                                          class="d-inline"
                                          onsubmit="return confirm('¿Estás seguro de eliminar este documento?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="tipo_documento" value="<?php echo e($campo); ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <button type="button" 
                                        class="btn btn-sm btn-outline-primary" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#uploadModal"
                                        data-tipo="<?php echo e($campo); ?>"
                                        data-nombre="<?php echo e($nombre); ?>">
                                    <i class="bi bi-cloud-upload"></i> Subir
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fichas-Tecnicas\TasbascoInn-Workers\resources\views/trabajadores/secciones_perfil/documentos.blade.php ENDPATH**/ ?>