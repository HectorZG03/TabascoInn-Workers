

<div class="row">
    <!-- Formulario de Datos Laborales -->
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">
                    <i class="bi bi-briefcase-fill"></i> Datos Laborales
                </h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('trabajadores.perfil.update-ficha', $trabajador)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row">
                        <!-- Área -->
                        <div class="col-md-6 mb-3">
                            <label for="id_area" class="form-label">
                                <i class="bi bi-building"></i> Área *
                            </label>
                            <select class="form-select <?php $__errorArgs = ['id_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="id_area" 
                                    name="id_area" 
                                    required>
                                <option value="">Seleccionar área...</option>
                                <?php if(isset($areas)): ?>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($area->id_area); ?>" 
                                                <?php echo e(old('id_area', $trabajador->fichaTecnica->categoria->id_area ?? '') == $area->id_area ? 'selected' : ''); ?>>
                                            <?php echo e($area->nombre_area); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['id_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Categoría -->
                        <div class="col-md-6 mb-3">
                            <label for="id_categoria" class="form-label">
                                <i class="bi bi-person-badge"></i> Categoría *
                            </label>
                            <select class="form-select <?php $__errorArgs = ['id_categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="id_categoria" 
                                    name="id_categoria" 
                                    required>
                                <option value="">Seleccionar categoría...</option>
                                <?php if(isset($categorias)): ?>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id_categoria); ?>" 
                                                <?php echo e(old('id_categoria', $trabajador->fichaTecnica->id_categoria ?? '') == $categoria->id_categoria ? 'selected' : ''); ?>>
                                            <?php echo e($categoria->nombre_categoria); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['id_categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Sueldo Diario -->
                        <div class="col-md-6 mb-3">
                            <label for="sueldo_diarios" class="form-label">
                                <i class="bi bi-cash"></i> Sueldo Diario *
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['sueldo_diarios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="sueldo_diarios" 
                                       name="sueldo_diarios" 
                                       value="<?php echo e(old('sueldo_diarios', $trabajador->fichaTecnica->sueldo_diarios ?? '')); ?>" 
                                       step="0.01"
                                       min="1"
                                       required>
                            </div>
                            <?php $__errorArgs = ['sueldo_diarios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Tipo de Cambio -->
                        <div class="col-md-6 mb-3">
                            <label for="tipo_cambio" class="form-label">
                                <i class="bi bi-arrow-up-circle"></i> Tipo de Cambio
                            </label>
                            <select class="form-select <?php $__errorArgs = ['tipo_cambio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="tipo_cambio" 
                                    name="tipo_cambio">
                                <option value="">Determinar automáticamente</option>
                                <option value="promocion" <?php echo e(old('tipo_cambio') == 'promocion' ? 'selected' : ''); ?>>
                                    🎉 Promoción
                                </option>
                                <option value="transferencia" <?php echo e(old('tipo_cambio') == 'transferencia' ? 'selected' : ''); ?>>
                                    🔄 Transferencia
                                </option>
                                <option value="aumento_sueldo" <?php echo e(old('tipo_cambio') == 'aumento_sueldo' ? 'selected' : ''); ?>>
                                    💰 Aumento de Sueldo
                                </option>
                                <option value="reclasificacion" <?php echo e(old('tipo_cambio') == 'reclasificacion' ? 'selected' : ''); ?>>
                                    📋 Reclasificación
                                </option>
                                <option value="ajuste_salarial" <?php echo e(old('tipo_cambio') == 'ajuste_salarial' ? 'selected' : ''); ?>>
                                    ⚖️ Ajuste Salarial
                                </option>
                            </select>
                            <small class="text-muted">Si no seleccionas, se determinará automáticamente</small>
                            <?php $__errorArgs = ['tipo_cambio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Motivo del Cambio -->
                        <div class="col-md-12 mb-3">
                            <label for="motivo_cambio" class="form-label">
                                <i class="bi bi-chat-text"></i> Motivo del Cambio
                            </label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['motivo_cambio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="motivo_cambio" 
                                   name="motivo_cambio" 
                                   value="<?php echo e(old('motivo_cambio')); ?>"
                                   placeholder="Ej: Promoción por excelente desempeño, Transferencia por necesidades operativas...">
                            <small class="text-muted">Opcional - Se registrará en el historial de cambios</small>
                            <?php $__errorArgs = ['motivo_cambio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Formación -->
                        <div class="col-md-6 mb-3">
                            <label for="formacion" class="form-label">
                                <i class="bi bi-mortarboard"></i> Formación Académica
                            </label>
                            <select class="form-select <?php $__errorArgs = ['formacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="formacion" 
                                    name="formacion">
                                <option value="">Seleccionar...</option>
                                <?php $__currentLoopData = ['Sin estudios', 'Primaria', 'Secundaria', 'Preparatoria', 'Universidad', 'Posgrado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($nivel); ?>" 
                                            <?php echo e(old('formacion', $trabajador->fichaTecnica->formacion ?? '') == $nivel ? 'selected' : ''); ?>>
                                        <?php echo e($nivel); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['formacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Grado de Estudios -->
                        <div class="col-md-6 mb-3">
                            <label for="grado_estudios" class="form-label">
                                <i class="bi bi-award"></i> Grado de Estudios
                            </label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['grado_estudios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="grado_estudios" 
                                   name="grado_estudios" 
                                   value="<?php echo e(old('grado_estudios', $trabajador->fichaTecnica->grado_estudios ?? '')); ?>">
                            <?php $__errorArgs = ['grado_estudios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- ✅ NUEVA SECCIÓN: HORARIO LABORAL -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2">
                                <i class="bi bi-clock"></i> Horario Laboral
                            </h6>
                        </div>
                        
                        <!-- Hora de Entrada -->
                        <div class="col-md-6 mb-3">
                            <label for="hora_entrada" class="form-label">
                                <i class="bi bi-door-open"></i> Hora de Entrada
                            </label>
                            <input type="time" 
                                   class="form-control <?php $__errorArgs = ['hora_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="hora_entrada" 
                                   name="hora_entrada" 
                                   value="<?php echo e(old('hora_entrada', optional($trabajador->fichaTecnica)->hora_entrada ? \Carbon\Carbon::parse($trabajador->fichaTecnica->hora_entrada)->format('H:i') : '')); ?>">
                            <?php $__errorArgs = ['hora_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <!-- Hora de Salida -->
                        <div class="col-md-6 mb-3">
                            <label for="hora_salida" class="form-label">
                                <i class="bi bi-door-closed"></i> Hora de Salida
                            </label>
                            <input type="time" 
                                   class="form-control <?php $__errorArgs = ['hora_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="hora_salida" 
                                   name="hora_salida" 
                                   value="<?php echo e(old('hora_salida', optional($trabajador->fichaTecnica)->hora_salida ? \Carbon\Carbon::parse($trabajador->fichaTecnica->hora_salida)->format('H:i') : '')); ?>">
                            <?php $__errorArgs = ['hora_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <!-- Días Laborables -->
                        <div class="col-md-12 mb-3">
                            <label class="form-label">
                                <i class="bi bi-calendar-week"></i> Días Laborables
                            </label>
                            <div class="dias-laborables-container">
                                <?php
                                    $diasLaborablesActuales = old('dias_laborables', optional($trabajador->fichaTecnica)->dias_laborables ?? []);
                                    // Convertir a array si es string (JSON)
                                    if (is_string($diasLaborablesActuales)) {
                                        $diasLaborablesActuales = json_decode($diasLaborablesActuales, true) ?? [];
                                    }
                                ?>
                                
                                <?php $__currentLoopData = \App\Models\FichaTecnica::DIAS_SEMANA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               id="dias_laborables_<?php echo e($key); ?>"
                                               name="dias_laborables[]"
                                               value="<?php echo e($key); ?>"
                                               <?php echo e(in_array($key, $diasLaborablesActuales) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="dias_laborables_<?php echo e($key); ?>"><?php echo e($dia); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php $__errorArgs = ['dias_laborables'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <!-- Días de Descanso (solo lectura) -->
                        <div class="col-md-12 mb-3">
                            <label class="form-label">
                                <i class="bi bi-calendar-event"></i> Días de Descanso
                            </label>
                            <div class="dias-descanso-container">
                                <?php
                                    $diasDescanso = \App\Models\FichaTecnica::calcularDiasDescanso($diasLaborablesActuales);
                                    $diasDescansoTexto = array_map(function($dia) {
                                        return \App\Models\FichaTecnica::DIAS_SEMANA[$dia] ?? $dia;
                                    }, $diasDescanso);
                                ?>
                                <p class="form-control-static"><?php echo e(implode(', ', $diasDescansoTexto) ?: 'No calculados'); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- ✅ NUEVA SECCIÓN: BENEFICIARIO -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2">
                                <i class="bi bi-person-heart"></i> Beneficiario Principal
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="beneficiario_nombre" class="form-label">
                                <i class="bi bi-person-badge"></i> Nombre Completo
                            </label>
                            <input type="text" 
                                   class="form-control <?php $__errorArgs = ['beneficiario_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="beneficiario_nombre" 
                                   name="beneficiario_nombre" 
                                   value="<?php echo e(old('beneficiario_nombre', optional($trabajador->fichaTecnica)->beneficiario_nombre ?? '')); ?>"
                                   placeholder="Nombre completo del beneficiario">
                            <?php $__errorArgs = ['beneficiario_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="beneficiario_parentesco" class="form-label">
                                <i class="bi bi-diagram-3"></i> Parentesco
                            </label>
                            <select class="form-select <?php $__errorArgs = ['beneficiario_parentesco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="beneficiario_parentesco" 
                                    name="beneficiario_parentesco">
                                <option value="">Seleccionar parentesco...</option>
                                <?php $__currentLoopData = \App\Models\FichaTecnica::PARENTESCOS_BENEFICIARIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $parentesco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" 
                                        <?php echo e(old('beneficiario_parentesco', optional($trabajador->fichaTecnica)->beneficiario_parentesco ?? '') == $key ? 'selected' : ''); ?>>
                                        <?php echo e($parentesco); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['beneficiario_parentesco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-save"></i> Actualizar Datos Laborales
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ✅ PANEL DE HISTORIAL CON VERIFICACIONES DE SEGURIDAD -->
    <div class="col-md-4">
        <div class="card shadow">
            <div class="card-header bg-info text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="bi bi-graph-up-arrow"></i> Historial de Cambios
                    </h6>
                    <?php if(Route::has('trabajadores.historial-promociones')): ?>
                        <a href="<?php echo e(route('trabajadores.historial-promociones', $trabajador)); ?>" 
                           class="btn btn-light btn-sm">
                            <i class="bi bi-eye"></i> Ver Todo
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body p-2">
                <?php if(isset($statsPromociones) && $statsPromociones['total_cambios'] > 0): ?>
                    <!-- ✅ ESTADÍSTICAS RÁPIDAS (CON VERIFICACIONES) -->
                    <div class="row text-center mb-3">
                        <div class="col-4">
                            <div class="text-success fw-bold"><?php echo e($statsPromociones['promociones'] ?? 0); ?></div>
                            <small class="text-muted">Promociones</small>
                        </div>
                        <div class="col-4">
                            <div class="text-primary fw-bold"><?php echo e($statsPromociones['transferencias'] ?? 0); ?></div>
                            <small class="text-muted">Transferencias</small>
                        </div>
                        <div class="col-4">
                            <div class="text-info fw-bold"><?php echo e($statsPromociones['total_cambios'] ?? 0); ?></div>
                            <small class="text-muted">Total</small>
                        </div>
                    </div>

                    <!-- ✅ ÚLTIMOS CAMBIOS (CON VERIFICACIONES) -->
                    <?php if(isset($historialReciente) && $historialReciente->isNotEmpty()): ?>
                        <div class="timeline-sm">
                            <?php $__currentLoopData = $historialReciente->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cambio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="timeline-item mb-2">
                                    <div class="d-flex">
                                        <div class="me-2">
                                            <span class="badge bg-<?php echo e($cambio->color_tipo_cambio ?? 'secondary'); ?> rounded-pill p-1">
                                                <?php if($cambio->tipo_cambio == 'promocion'): ?>
                                                    <i class="bi bi-arrow-up"></i>
                                                <?php elseif($cambio->tipo_cambio == 'transferencia'): ?>
                                                    <i class="bi bi-arrow-left-right"></i>
                                                <?php elseif($cambio->tipo_cambio == 'aumento_sueldo'): ?>
                                                    <i class="bi bi-cash"></i>
                                                <?php else: ?>
                                                    <i class="bi bi-gear"></i>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="small fw-bold"><?php echo e($cambio->tipo_cambio_texto ?? 'Cambio'); ?></div>
                                            <div class="text-muted small">
                                                <?php echo e($cambio->categoriaNueva->nombre_categoria ?? 'Sin categoría'); ?>

                                            </div>
                                            <div class="text-success small">
                                                $<?php echo e(number_format($cambio->sueldo_nuevo ?? 0, 2)); ?>

                                                <?php if(isset($cambio->sueldo_anterior) && $cambio->sueldo_anterior > 0): ?>
                                                    <small class="text-muted">
                                                        (<?php echo e(($cambio->diferencia_sueldo ?? 0) >= 0 ? '+' : ''); ?>$<?php echo e(number_format($cambio->diferencia_sueldo ?? 0, 2)); ?>)
                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                            <div class="text-muted small">
                                                <?php echo e($cambio->fecha_cambio ? $cambio->fecha_cambio->format('d/m/Y') : 'Fecha no disponible'); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if(!$loop->last): ?><hr class="my-2"><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-3">
                            <i class="bi bi-graph-up fs-2 opacity-50"></i>
                            <p class="mb-0 small">Sin historial reciente</p>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- ✅ ESTADO VACÍO -->
                    <div class="text-center text-muted py-3">
                        <i class="bi bi-graph-up fs-2 opacity-50"></i>
                        <p class="mb-0 small">Sin historial de cambios</p>
                        <small class="text-muted">Los cambios aparecerán aquí cuando actualices los datos laborales</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php if(config('app.debug')): ?>
    <div class="mt-3">
        <details class="border rounded p-2 bg-light">
            <summary class="text-muted small">🔍 Debug Info</summary>
            <div class="mt-2 small">
                <strong>Variables disponibles:</strong><br>
                - $statsPromociones: <?php echo e(isset($statsPromociones) ? '✅' : '❌'); ?><br>
                - $historialReciente: <?php echo e(isset($historialReciente) ? '✅' : '❌'); ?><br>
                - $areas: <?php echo e(isset($areas) ? '✅' : '❌'); ?><br>
                - $categorias: <?php echo e(isset($categorias) ? '✅' : '❌'); ?><br>
                
                <?php if(isset($statsPromociones)): ?>
                    <strong>Stats:</strong> <?php echo e(json_encode($statsPromociones)); ?><br>
                <?php endif; ?>
                
                <?php if(isset($historialReciente)): ?>
                    <strong>Historial count:</strong> <?php echo e($historialReciente->count()); ?><br>
                <?php endif; ?>
            </div>
        </details>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Fichas-Tecnicas\TasbascoInn-Workers\resources\views/trabajadores/secciones_perfil/datos_laborales.blade.php ENDPATH**/ ?>